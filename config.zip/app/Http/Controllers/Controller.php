<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, ValidatesRequests;

    public function index(){
        return view('welcome');
    }
    public function login(){
        return view('login');
    }
    public function register(){
        return view('register');
    }
    public function about(){
        return view('about');
    }
    public function hot(){
        return view('hot');
    }
    public function admit(){
        return view('admit');
    }
    public function check(){
        return view('check');
    }
    public function editpa(){
        return view('editpa');
    }
    public function demo(){
        return view('demo1');
    }



}
