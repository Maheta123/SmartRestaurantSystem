<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Models\patients;


use App\Models\Product; // Adjust this to match the correct namespace and model name

// ...


class HospitalController extends Controller
{
    //
    public function index(){
        return view('admit');
    }

    public function store(Request $request){

        $request->validate([
            "pname"=> "required",
            "page"=>"required",
            "pimage"=>"required",
            "gender"=>"required",
            "illness"=>"required",
    ]);

        $product = new patients;
        if ($request->hasFile('image') && $request->file('image')->isValid()) {
            $request->pimage = time() . '.' . $request->image->extension();
         } else {
            // Handle the case where no valid image file is uploaded or errors occur
        }

            $product->pname = $request->pname;
            $product->page = $request->page;
            $product->pimage = $request->pimage;
            $product->gender = $request->gender;
            $product->illness = $request->illness;
            $product->bg = $request->bg;

            // Save the product to the database
            $product->save();

            // Redirect back after saving
            return back();

    }
    public function fetch($id) {
        // Here, $id is received from the route parameter

        dd($id);
        //        $data= patients::where('id',$id)->first();
        //        return view('check',['data'=>$data]);
        // // Pass the $id variable to the view
        //return view('check', compact('id'));
    }




}
