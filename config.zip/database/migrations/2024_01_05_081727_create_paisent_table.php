<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('patients', function (Blueprint $table) {
            $table->increments('patient_id')->unsigned();
            $table->string('pname', 60);
            $table->unsignedBigInteger('page'); // Change to unsignedBigInteger if you expect large numbers
            $table->enum('gender', ['M', 'F', 'o']);
            $table->string('illness', 60);
            $table->string('bg', 5);
            $table->string('pimage', 350);
            $table->timestamps();
        });

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
