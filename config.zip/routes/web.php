<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
use App\Http\Controllers\Controller;
use App\Http\Controllers\HospitalController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[Controller::class,'index']);
Route::get('/login',[Controller::class,'login']);
Route::get('/register',[Controller::class,'register']);
Route::get('/about',[Controller::class,'about']);
Route::get('/hot',[Controller::class,'hot']);
Route::get('/admit',[Controller::class,'admit']);
Route::get('/check',[Controller::class,'check']);
Route::get('/editpa',[Controller::class,'editpa']);
Route::get('/demo',[Controller::class,'demo']);


Route::get('/check/id',[HospitalController::class,'fetch']);
Route::get('/check/{id}/show',[HospitalController::class,'fetch']);
Route::post('/store',[HospitalController::class,'store']);

